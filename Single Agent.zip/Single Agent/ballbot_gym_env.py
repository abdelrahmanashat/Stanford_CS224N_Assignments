"""This file implements the gym environment of ballbot.

"""

import os, inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(os.path.dirname(currentdir))
os.sys.path.insert(0, parentdir)

from typing import Optional, Dict

import math
import time
import gymnasium as gym
from gymnasium import spaces
from gymnasium.utils import seeding
from isaacgym import gymapi
import isaacgym.terrain_utils as terrain_utils
import numpy as np
import random
from stable_baselines3 import TD3

from . import ballbot
from .ground_type import GroundType
from pkg_resources import parse_version

ACTION_EPS = 0.01
OBSERVATION_EPS = 0.01
RENDER_HEIGHT = 720
RENDER_WIDTH = 960
CAMERA_SETTINGS = [[0, 0, 0], [0, 6, 6]] # [Target, Position]

class BallbotGymEnv(gym.Env):
  """The gym environment for the ballbot.

  It simulates the locomotion of a ballbot. The state space
  include the angles, velocities and torques for all the omniwheels and the action
  space is the desired omniwheel torque for each omniwheel. The reward function is based
  on how far the ballbot walks in 1000 steps and penalizes the energy
  expenditure.

  """
  metadata = {"render_modes": [None, "human", "rgb_array"]}

  def __init__(
      self,
      render=True,
      time_step=1 / 60,      
      numSubSteps=2,
      env_num=0,
      env_spacing=5,
      env_max_episode_length=10000,
      action_bound=1,
      max_torque=10,
      max_speed=1000,
      num_omniwheels=3,
      action_history_length=1,
      distance_limit=float("inf"),
      ballbot_light=False,
      built_in_ball=True,
      add_object=False,
      add_random_force_at_sec=None,
      ground_type=None,
      observation_noise_stdev=0.0,
      pid_control_enabled=True,
      torque_control=True,
      physics_engine_PhysX=True,
      random_start_position=False,
      operation_mode=0):
    """Initialize the ballbot gym environment.

    Args:
      render: Whether to render the simulation.
      time_step: Step time of the simulation.
      numSubSteps: The number of substeps is another parameter. The bigger it gets, the smoother the simulation becomes.
      action_repeat: The number of simulation steps before actions are applied.
      action_bound: The maximum value of the action
      distance_weight: The weight of the distance term in the reward.
      energy_weight: The weight of the energy term in the reward.
      shake_weight: The weight of the vertical shakiness term in the reward.
      drift_weight: The weight of the sideways drift term in the reward.
      distance_limit: The maximum distance to terminate the episode.
      built_in_ball: Use the ball created inside the simulator or load it from URDF file.
      ballbot_light: Use the light ballbot with the ominwheel and its subwheels are treated as one link.
      observation_noise_stdev: The standard deviation of observation noise.
      self_collision_enabled: Whether to enable self collision in the sim.
      pid_control_enabled: Whether to use pid control for the omniwheels (inactive if accurate_motor_model_enabled is enabled).
      hard_reset: Whether to wipe the simulation and load everything when reset
        is called. If set to false, reset just place the ballbot back to start
        position and set its pose to initial configuration.
      env_randomizer: An EnvRandomizer to randomize the physical properties
        during reset().
    """
    self._is_render = render
    self._time_step = time_step
    self._numSubSteps = numSubSteps
    self._env_num = env_num
    self._env_spacing = env_spacing
    self._env_max_episode_length = env_max_episode_length
    self._action_bound = action_bound
    self._max_torque = max_torque
    self._max_speed = max_speed
    self._num_omniwheels = num_omniwheels
    self._action_history_length = action_history_length
    self._distance_limit = distance_limit
    self._built_in_ball = built_in_ball
    self._ballbot_light = ballbot_light
    self._add_object = add_object
    self._add_random_force_at_sec = add_random_force_at_sec
    self._ground_type = ground_type
    self._observation_noise_stdev = observation_noise_stdev
    self._pid_control_enabled = pid_control_enabled        
    self._torque_control = torque_control
    self._physics_engine_PhysX = physics_engine_PhysX
    self._random_start_position = random_start_position
    self._operation_mode = operation_mode
    
    # Initialize Gym Client
    self._gym_client = gymapi.acquire_gym()

    # Initialize Sim Client
    compute_device_id = 0
    graphics_device_id = 0
    # Set common simulation parameters
    sim_params = gymapi.SimParams()
    sim_params.dt = self._time_step
    sim_params.substeps = self._numSubSteps
    sim_params.up_axis = gymapi.UP_AXIS_Z
    sim_params.gravity = gymapi.Vec3(0.0, 0.0, -9.8) 
    sim_params.use_gpu_pipeline = False
    
    # set PhysX-specific parameters
    if self._physics_engine_PhysX:
      sim_params.physx.use_gpu = True
      sim_params.physx.contact_offset = 0.015
      sim_params.physx.max_depenetration_velocity = 5
      sim_params.physx.num_position_iterations = 6
      #sim_params.physx.friction_offset_threshold = 0.001
      sim_params.physx.rest_offset = 0
      self._sim_client = self._gym_client.create_sim(compute_device_id, graphics_device_id, gymapi.SIM_PHYSX, sim_params)
    else:
    # set Flex-specific parameters
      sim_params.flex.solver_type = 5
      sim_params.flex.num_outer_iterations = 6
      sim_params.flex.num_inner_iterations = 20
      sim_params.flex.relaxation = 0.8
      sim_params.flex.warm_start = 0.5
      sim_params.flex.shape_collision_margin = 0.01
      sim_params.flex.friction_mode = 2
      sim_params.flex.static_friction = 0.1
      sim_params.flex.dynamic_friction = 0.1
      self._sim_client = self._gym_client.create_sim(compute_device_id, graphics_device_id, gymapi.SIM_FLEX, sim_params)
    
    if self._ground_type is None:
      # Add normal ground 
      # configure the ground plane
      plane_params = gymapi.PlaneParams()
      plane_params.normal = gymapi.Vec3(0, 0, 1) # z-up!
      plane_params.distance = 0
      plane_params.static_friction = 2.1
      plane_params.dynamic_friction = 2.1
      plane_params.restitution = 0
      # create the ground plane
      self._gym_client.add_ground(self._sim_client, plane_params)
    else:
      ground_width = 12.
      ground_length = 12.
      horizontal_scale = 0.25  # [m]
      vertical_scale = 0.005  # [m]
      num_rows = int(ground_width/horizontal_scale)
      num_cols = int(ground_length/horizontal_scale)
      heightfield = np.zeros((num_rows, num_cols), dtype=np.int16)
      new_sub_terrain = terrain_utils.SubTerrain(width=num_rows, length=num_cols, vertical_scale=vertical_scale, horizontal_scale=horizontal_scale)
      
      # check if ground_type is valid
      assert isinstance(self._ground_type, GroundType), f"Invalid ground type, please use one of {list(GroundType)}"
      
      if self._ground_type == GroundType.GROUND_RANDOM_UNIFORM:
        heightfield = terrain_utils.random_uniform_terrain(new_sub_terrain, min_height=-0.1, max_height=0.1, step=0.1, downsampled_scale=0.5).height_field_raw
      elif self._ground_type == GroundType.GROUND_SLOPED:
        heightfield = terrain_utils.sloped_terrain(new_sub_terrain, slope=-0.15).height_field_raw
      elif self._ground_type == GroundType.GROUND_PYRAMID_SLOPED:
        heightfield = terrain_utils.pyramid_sloped_terrain(new_sub_terrain, slope=-0.15, platform_size=1.).height_field_raw
      elif self._ground_type == GroundType.GROUND_DISCRETE_OBSTACLES:
        heightfield = terrain_utils.discrete_obstacles_terrain(new_sub_terrain, max_height=0.1, min_size=1., max_size=5., num_rects=20, platform_size=1.).height_field_raw
      elif self._ground_type == GroundType.GROUND_WAVE:
        heightfield = terrain_utils.wave_terrain(new_sub_terrain, num_waves=3., amplitude=0.4).height_field_raw
      elif self._ground_type == GroundType.GROUND_STAIRS:
        heightfield = terrain_utils.stairs_terrain(new_sub_terrain, step_width=1, step_height=-0.15).height_field_raw
      elif self._ground_type == GroundType.GROUND_PYRAMID_STAIRS:
        heightfield = terrain_utils.pyramid_stairs_terrain(new_sub_terrain, step_width=1.5, step_height=-0.1).height_field_raw
      elif self._ground_type == GroundType.GROUND_STEPPING_STONES:
        heightfield = terrain_utils.stepping_stones_terrain(new_sub_terrain, stone_size=4., stone_distance=0.4, max_height=0, platform_size=1., depth=-1).height_field_raw
      
      # add the terrain as a triangle mesh
      vertices, triangles = terrain_utils.convert_heightfield_to_trimesh(heightfield, horizontal_scale=horizontal_scale, vertical_scale=vertical_scale, slope_threshold=1.5)
      tm_params = gymapi.TriangleMeshParams()
      tm_params.nb_vertices = vertices.shape[0]
      tm_params.nb_triangles = triangles.shape[0]
      tm_params.transform.p.x = -self._env_spacing
      tm_params.transform.p.y = -self._env_spacing
      tm_params.static_friction = 2.1
      tm_params.dynamic_friction = 2.1
      tm_params.restitution = 0
      self._gym_client.add_triangle_mesh(self._sim_client, vertices.flatten(), triangles.flatten(), tm_params)
        
    # Initialize Env Client
    lower = gymapi.Vec3(-self._env_spacing, -self._env_spacing, -self._env_spacing)
    upper = gymapi.Vec3(self._env_spacing, self._env_spacing, self._env_spacing)
    self._env = self._gym_client.create_env(self._sim_client, lower, upper, 1)
      
    # Initialize The Ballbot
    self.ballbot = ballbot.Ballbot(sim_client=self._sim_client,
                                     gym_client=self._gym_client,
                                     env=self._env,
                                     collision_group=self._env_num,
                                     built_in_ball=self._built_in_ball,
                                     ballbot_light=self._ballbot_light,
                                     add_object=self._add_object,
                                     ground_type=self._ground_type,
                                     torque_control=self._torque_control,
                                     max_torque=self._max_torque,
                                     max_speed=self._max_speed,
                                     pid_control_enabled=self._pid_control_enabled,
                                     physics_engine_PhysX=self._physics_engine_PhysX,
                                     random_start_position=self._random_start_position,
                                     num_omniwheels=self._num_omniwheels)
    
    if self._is_render:
      # Create camera sensor for image extraction
      cam_props = gymapi.CameraProperties()
      cam_props.horizontal_fov = 10
      cam_props.width = RENDER_WIDTH
      cam_props.height = RENDER_HEIGHT
      self.camera_handle = self._gym_client.create_camera_sensor(self._env, cam_props)
      # Create only one viewer for any number of environments
      if self._env_num == 0:
        # General viewer options
        cam_props = gymapi.CameraProperties()
        cam_props.horizontal_fov = 10
        self.viewer = self._gym_client.create_viewer(self._sim_client, cam_props)
        # Subscribe some actions to keyboard and mouse
        self._gym_client.subscribe_viewer_mouse_event(self.viewer, gymapi.MOUSE_SCROLL_UP, "ZoomIn")
        self._gym_client.subscribe_viewer_mouse_event(self.viewer, gymapi.MOUSE_SCROLL_DOWN, "ZoomOut")
        self._gym_client.subscribe_viewer_keyboard_event(self.viewer, gymapi.KEY_UP, "MoveReferenceUp")
        self._gym_client.subscribe_viewer_keyboard_event(self.viewer, gymapi.KEY_DOWN, "MoveReferenceDown")
        self._gym_client.subscribe_viewer_keyboard_event(self.viewer, gymapi.KEY_RIGHT, "MoveReferenceRight")
        self._gym_client.subscribe_viewer_keyboard_event(self.viewer, gymapi.KEY_LEFT, "MoveReferenceLeft")
    
    self.seed()
    BallbotGymEnv.reset(self)
    
    if(self._operation_mode==1): # Reference Tracking Training Mode
      model_path = os.path.join(os.path.dirname(__file__), "Balance_Training_SmallNetwork_Fixed.zip")
      self._model_TD3 = TD3.load(model_path)
    
    observation_high = (self.GetObservationUpperBound() + OBSERVATION_EPS)
    observation_low = (self.GetObservationLowerBound() - OBSERVATION_EPS)
    if(self._operation_mode==1): # Reference Tracking Training Mode
      action_dim = 2 #
      action_high = np.array([self._action_bound] * action_dim, dtype=np.float32)
    else:
      action_dim = self._num_omniwheels
      action_high = np.array([self._action_bound] * action_dim, dtype=np.float32)
    self.action_space = spaces.Box(-action_high, action_high, dtype=np.float32)
    self.observation_space = spaces.Box(np.float32(observation_low), np.float32(observation_high), dtype=np.float32)

  def configure(self, args):
    self._args = args

  def reset(self,*, seed: Optional[int] = None, options: Optional[Dict] = None):
    if seed is not None:
      super().reset(seed=seed)
      
    self.ballbot.Reset()
        
    import torch    
    with torch.no_grad():
        torch.cuda.empty_cache()
    
    # Viewer Settings
    self._cam_target = CAMERA_SETTINGS[0]
    self._previous_cam_target = self._cam_target
    self._cam_position = CAMERA_SETTINGS[1]
    
    # Temporary Simulation Variables
    self._stable_time_reward = 1
    self._env_step_counter = 0
    self._last_base_position = self.get_ballbot_base_position()
    self._objectives = []
    self._action_history = [] 
    self._max_angle_desired = 5 * np.pi / 180
    self._previous_tracking_penalty = 0
    self._running_position_error = 0
    self._running_velocity_error = 0
    self._radius = 0.2
    self.set_ball_reference_position(self.generate_random_reference_position_within_radius(self._radius))
    self.reference_change_count = 0
    self._env_closed = False
    if self._operation_mode == 0:
      [self._theta_x_desired, self._theta_y_desired] = self.generate_random_desired_angles(self._max_angle_desired)
    
    self._step_simulation()             # Just to begin simulation
    
    return self.GetNoisyObservation(), {}

  def seed(self, seed=None):
    self.np_random, seed = seeding.np_random(seed)
    return [seed]
  
  def _is_action_in_range(self, action):
    for i, action_component in enumerate(np.array(action)):
      if not (-self._action_bound - ACTION_EPS <= action_component.item() and action_component.item() <= self._action_bound + ACTION_EPS):
        raise ValueError("{}th action {} out of bounds.".format(i, action_component.item()))
  
  def _step_simulation(self):
    # step the physics
    self._gym_client.simulate(self._sim_client)
    self._gym_client.fetch_results(self._sim_client, True)  # The second argument is flags if should wait for latest simulation step to complete.
    
    # update the viewer
    if self._is_render:
      if not self._gym_client.query_viewer_has_closed(self.viewer):
        self._gym_client.step_graphics(self._sim_client)
    
        # Update camera position and target
        self._gym_client.set_camera_location(self.camera_handle, self._env, gymapi.Vec3(*self._cam_position), gymapi.Vec3(*self._cam_target))
        # render camera sensor
        self._gym_client.render_all_camera_sensors(self._sim_client)
        
        # Zoom in or out depending on mouse scroll
        for event in self._gym_client.query_viewer_action_events(self.viewer):
          if event.action == "ZoomIn" and event.value > 0:
            self._cam_position[1] = self._cam_position[1] - 1
            self._cam_position[2] = self._cam_position[2] - 1
          elif event.action == "ZoomOut" and event.value > 0:
            self._cam_position[1] = self._cam_position[1] + 1
            self._cam_position[2] = self._cam_position[2] + 1
          elif event.action == "MoveReferenceUp" and event.value > 0:
            [x, y] = self._reference_ball_position
            self.set_ball_reference_position(np.array([x, y - 0.1]))
          elif event.action == "MoveReferenceDown" and event.value > 0:
            [x, y] = self._reference_ball_position
            self.set_ball_reference_position(np.array([x, y + 0.1]))
          elif event.action == "MoveReferenceRight" and event.value > 0:
            [x, y] = self._reference_ball_position
            self.set_ball_reference_position(np.array([x - 0.1, y]))
          elif event.action == "MoveReferenceLeft" and event.value > 0:
            [x, y] = self._reference_ball_position
            self.set_ball_reference_position(np.array([x + 0.1, y]))
            
        
        # Update viewer camera position
        base_pos = self.get_ballbot_base_position()
        self._cam_target = [0.95 * self._previous_cam_target[0] + 0.05 * base_pos[0], 0.95 * self._previous_cam_target[1] + 0.05 * base_pos[1], self._previous_cam_target[2]] 
        self._previous_cam_target = self._cam_target
        self._gym_client.viewer_camera_look_at(self.viewer,self._env,gymapi.Vec3(*self._cam_position),gymapi.Vec3(*self._cam_target))
        
        self._gym_client.draw_viewer(self.viewer, self._sim_client, True)  # The third argument is renderCollisionMeshes flag to determine if should render the collision meshes instead of display meshes
        self._gym_client.sync_frame_time(self._sim_client)
      else:
        self.close()


  def step(self, action):
    """Step forward the simulation, given the action.

    Args:
      action: A list of desired omniwheel angles for three omniwheels.

    Returns:
      observations: The angles, velocities and torques of all omniwheels.
      reward: The reward for the current state-action pair.
      done: Whether the episode has ended.
      truncated: Whether the episode has reached the maximum number of timesteps.
      info: A dictionary that stores diagnostic information.

    Raises:
      ValueError: The action dimension is not the same as the number of omniwheels.
      ValueError: The magnitude of actions is out of bounds.
    """
    #print("step no.",self._env_step_counter)
    #a=self._gym_client.get_env_rigid_contacts(self._env)
    #c=1
    #for i in a:
    #  print(c)
    #  c=c+1
    #  print("body0:",i["body0"])
    #  print("body1:",i["body1"])
    #  print("env0:",i["env0"])
    #  print("env1:",i["env1"])
    #  print("friction:",i["friction"])
    #  print("lambda:",i["lambda"])
    #  print("normal:",i["normal"])
    #  print("offset0:",i["offset0"])
    #  print("offset1:",i["offset1"])
    #  print("")
    
    #ref_observation = np.array(action, dtype=np.float32)
    #cur_observation = []
    #[theta_x, theta_y, theta_z] = self.get_ballbot_base_orientation_eulerform()
    #cur_observation.extend([np.sin(theta_x), np.sin(theta_y), np.cos(theta_x), np.cos(theta_y)])
    #[_, AngVelocity] = self.get_ballbot_base_velocity()
    #[AngVelocity_x, AngVelocity_y, _] = AngVelocity
    #cur_observation.extend([AngVelocity_x/(6*np.pi), AngVelocity_y/(6*np.pi)])
    
    #error_observation = ref_observation - np.array(cur_observation)
    #action_balance, _ = self._model_DDPG.predict(error_observation)
    
    if(self._operation_mode==1): # Reference Tracking Training Mode
      if len(action) != 2:
        raise ValueError("Action dimension = {}. It should be {}".format(len(action), 2))
    else:
      if len(action) != self._num_omniwheels:
        raise ValueError("Action dimension = {}. It should be {}".format(len(action), self._num_omniwheels))
    
    if self._add_random_force_at_sec is not None and np.any(np.array(self._add_random_force_at_sec) / self._time_step == self._env_step_counter):
      force_values = [30,35,40,45,50,-30,-35,-40,-45,-50]
      force_x = random.choice(force_values)
      force_y = random.choice(force_values)
      force = gymapi.Vec3(force_x,force_y,0)
      print(f"Applying Force ({force_x},{force_y},0) N at the center of mass of ballbot")
      self.ballbot.ApplyForceAtBallbot(force)
    
    self._action_history.append(action)
    if len(self._action_history) > self._action_history_length:
      self._action_history.pop(0)
    
    if self._pid_control_enabled:
      self.ballbot.ApplyAction(action)  
    else:  
      if self._torque_control:
        if(self._operation_mode==1): # Reference Tracking Training Mode
          [self._theta_x_desired, self._theta_y_desired] = action
          self._theta_x_desired = self._theta_x_desired * self._max_angle_desired
          self._theta_y_desired = self._theta_y_desired * self._max_angle_desired
          [theta_x, theta_y, theta_z] = self.get_ballbot_base_orientation_eulerform()
          [_, AngVelocity] = self.get_ballbot_base_velocity()
          [AngVelocity_x, AngVelocity_y, _] = AngVelocity
          obs = [np.sin(theta_x), np.sin(theta_y), np.cos(theta_x), np.cos(theta_y), AngVelocity_x/(6*np.pi), AngVelocity_y/(6*np.pi), self._theta_x_desired/self._max_angle_desired, self._theta_y_desired/self._max_angle_desired]
          action, _ = self._model_TD3.predict(np.array(obs))
        self._is_action_in_range(action)
        self.ballbot.ApplyAction(action)
      else:
        position = np.array(action) * (np.pi * 2)
        self._is_action_in_range(action)
        self.ballbot.ApplyAction(list(position))
    
    self._step_simulation()
    if not self._env_closed:
      self._env_step_counter += 1
      reward = self._reward()
      done = self._termination()
      truncated = self._truncation()
      
      return self.GetNoisyObservation(), reward, done, truncated, {}
    else:
      return self.GetNoisyObservation(),0.0,True,True,{}

  def get_image(self, mode=None):
    """Get the current frame of the ballbot.

    Returns:
      An RGBA image as a numpy array in the shape [RENDER_HEIGHT, RENDER_WIDTH, 4].
    """
    if mode != "rgb_array":
        return np.array([])
    
    # Get camera image in the "RGBA" form. The output of this function is a numpy array in the shape: [RENDER_HEIGHT, RENDER_WIDTH*4]
    camera_image = self._gym_client.get_camera_image(self._sim_client, self._env, self.camera_handle, gymapi.IMAGE_COLOR)
    
    # Convert to RGBA image in the shape [RENDER_HEIGHT, RENDER_WIDTH, 4]
    rgb_array = self._2D_to_3d_RGBA(camera_image)
    return rgb_array

  def get_ballbot_base_position(self):
    """Get the ballbot's base orientation, represented by a quaternion.

    Returns:
      A list of ballbot's base position.
    """
    return self.ballbot.GetBasePosition()
    
  def get_ballbot_base_orientation(self):
    """Get the ballbot's base orientation, represented by a quaternion.

    Returns:
      A list of ballbot's base orientation.
    """
    return self.ballbot.GetBaseOrientation()
  
  def get_ballbot_base_orientation_eulerform(self):
    """Get the ballbot's base orientation, represented by a xyz angles.

    Returns:
      A list of ballbot's base orientation in Euler form.
    """
    return self.ballbot.GetBaseOrientationEulerForm()
  
  def get_ballbot_base_velocity(self):
    """Get the velocity of ballbot's base.

    Returns:
      The velocity of ballbot's base in the following order: [Linear Velocity, Angular Velocity].
    """
    return self.ballbot.GetBaseVelocity()
  
  def get_ball_position(self):
    """Get the position of ball.

    Returns:
      The position of ball.
    """
    return self.ballbot.GetBallPosition()
    
  def get_ball_reference_position(self):
    """Get the current reference position of ball.

    Returns:
      The current reference position of ball.
    """
    return self._reference_ball_position
  
  def get_ball_orientation(self):
    """Get the orientation of ball's base, represented as quaternion.

    Returns:
      The orientation of ball's base.
    """
    return self.ballbot.GetBallOrientation()
  
  def get_ball_orientation_eulerform(self):
    """Get the orientation of ball's base, represented as Euler.

    Returns:
      The orientation of ball's base in Euler form.
    """
    return self.ballbot.GetBallOrientationEulerForm()
    
  def get_ball_velocity(self):
    """Get the velocity of ball.

    Returns:
      The velocity of ball in the following order: [Linear Velocity, Angular Velocity].
    """
    return self.ballbot.GetBallVelocity()
  
  def get_ballbot_omniwheel_angles(self):
    """Get the ballbot's omniwheel angles.

    Returns:
      A list of omniwheel angles.
    """
    return self.ballbot.GetOmniwheelAngles()

  def get_ballbot_omniwheel_velocities(self):
    """Get the velocity of all three omniwheels in rad/s.

    Returns:
      A list of angular velocities of all three omniwheels.
    """
    return self.ballbot.GetOmniwheelVelocities()

  def get_ballbot_omniwheel_torques(self):
    """Get the amount of torques the omniwheels are exerting in N.m.

    Returns:
      A list of omniwheel torques of all three motors.
    """
    return self.ballbot.GetOmniwheelTorques()  
  
  def get_object_position(self):
    """Get the amount of torques the omniwheels are exerting in N.m.

    Returns:
      A list of omniwheel torques of all three motors.
    """
    return self.ballbot.GetObjectPosition()
  
  def get_max_angle_desired(self):
    """Get the maximum desired angle in radians.

    Returns:
      The maximum desired angle.
    """
    return self._max_angle_desired
  
  def generate_random_reference_position_within_radius(self, radius):
    """Generates a random reference point within a given radius of the current ball position.
    Args:
      radius: A float that is radius of the range we want the reference to be in.
    Returns:
      A numpy array [x, y] of the generated reference.
    """
    [ball_x, ball_y, _] = self.get_ball_position()
    r = radius * np.sqrt(np.random.uniform(0,1))
    theta = random.random() * 2 * np.pi
    x = ball_x + r * np.cos(theta)
    y = ball_y + r * np.sin(theta)
    return np.array([x, y])
  
  def set_ball_reference_position(self, value):
    """Set the current reference position of ball.
    Args:
      value: A numpy array [x, y] of the desired reference for the ball.
    """
    self._reference_ball_position = value
    if self._is_render:
      self._draw_reference_sign()
 
  def _draw_reference_sign(self):
    """Draw a big X on the screen crossed at the reference point for visual.
    """
    self._gym_client.clear_lines(self.viewer)
    [x_ref, y_ref] = self._reference_ball_position
    [_, _, z] = self.get_ball_position()
    lines_count = 2
    line_length = 0.1
    line_color = (0.85, 0, 0)
    first_line_location = (x_ref+line_length, y_ref+line_length, z, x_ref-line_length, y_ref-line_length, z)
    second_line_location = (x_ref-line_length, y_ref+line_length, z, x_ref+line_length, y_ref-line_length, z)
    self._gym_client.add_lines(self.viewer, self._env, lines_count, [first_line_location, second_line_location], [line_color, line_color])
    
  def generate_random_desired_angles(self, max_angle):
    """Generates random theta_x_desired and theta_y_desired within the range [-max_angle, max_angle].
    Args:
      max_angle: Maximum desired angle
    Returns:
      A list of [theta_x_desired, theta_y_desired]
    """
    theta_x_desired = np.random.uniform(-1,1) * max_angle
    theta_y_desired = np.random.uniform(-1,1) * max_angle
    return [theta_x_desired, theta_y_desired]
  
  def GetActionDimension(self):
    """Get the length of the action list.

    Returns:
      The length of the action list.
    """
    return self._num_omniwheels
                    
  def GetObservationUpperBound(self):
    """Get the upper bound of the observation.

    Returns:
      The upper bound of an observation. See GetObservation() for the details
        of each element of an observation.
    """
    upper_bound = np.array([0.0] * self.GetObservationDimension())
    
    if(self._operation_mode==0):
      upper_bound[0:4] = 1  # Sine and cosine.
      upper_bound[4:6] = 1  # Ballbot angular velocity.
      upper_bound[6:8] = 1  # Ballbot desired angle.
      
    elif(self._operation_mode==1):	# Reference Tracking Training Mode	  
      upper_bound[0:2] = 1  # Ball position.
      upper_bound[2:4] = 1  # Ball reference position.
    
    elif(self._operation_mode==2):  # Testing Mode
      upper_bound[0:4] = 1  # Sine and cosine.
      upper_bound[4:6] = 1  # Ballbot angular velocity.
      upper_bound[6:8] = 1  # Ball position.
      upper_bound[8:10] = 1  # Ball reference position.
    
    return upper_bound

  def GetObservationLowerBound(self):
    """Get the lower bound of the observation.
    
    Returns:
      The lower bound of an observation. See GetObservation() for the details
        of each element of an observation.
    """
    return -self.GetObservationUpperBound()

  def GetObservationDimension(self):
    """Get the length of the observation list.

    Returns:
      The length of the observation list.
    """
    return len(self.GetObservation())

  def GetObservation(self):                    
    """Get the observations of ballbot.

    It includes the angles, velocities, torques and the orientation of the base.

    Returns:
      The observation list: 
      observation[0:3] are base position. 
      observation[3:4] is sine of ballbot orientation angle around x-axis,
      observation[4:5] is sine of ballbot orientation angle around y-axis,
      observation[5:6] is cosine of ballbot orientation angle around x-axis,
      observation[6:7] is cosine of ballbot orientation angle around y-axis,
      observation[7:9] are linear velocities of ballbot in the x-axis and y-axis respectively,
      observation[9:11] are angular velocities of ballbot around the x-axis and y-axis respectively.
    """
    observation = []
    if(self._operation_mode==0):
      [theta_x, theta_y, theta_z] = self.get_ballbot_base_orientation_eulerform()
      observation.extend([np.sin(theta_x), np.sin(theta_y), np.cos(theta_x), np.cos(theta_y)])
      
      [_, AngVelocity] = self.get_ballbot_base_velocity()
      [AngVelocity_x, AngVelocity_y, _] = AngVelocity
      observation.extend([AngVelocity_x/(6*np.pi), AngVelocity_y/(6*np.pi)])
      
      observation.extend([self._theta_x_desired/self._max_angle_desired, self._theta_y_desired/self._max_angle_desired])
      
    elif(self._operation_mode==1):	# Reference Tracking Training Mode	  
      [x, y, _] = self.get_ball_position()
      observation.extend([x/self._env_spacing, y/self._env_spacing])
      
      [x_ref, y_ref] = self._reference_ball_position
      observation.extend([x_ref/self._env_spacing, y_ref/self._env_spacing])
      
    elif(self._operation_mode==2):   # Testing Mode
      [theta_x, theta_y, theta_z] = self.get_ballbot_base_orientation_eulerform()
      observation.extend([np.sin(theta_x), np.sin(theta_y), np.cos(theta_x), np.cos(theta_y)])
      
      [_, AngVelocity] = self.get_ballbot_base_velocity()
      [AngVelocity_x, AngVelocity_y, _] = AngVelocity
      observation.extend([AngVelocity_x/(6*np.pi), AngVelocity_y/(6*np.pi)])
      
      [x, y, _] = self.get_ball_position()
      observation.extend([x/self._env_spacing, y/self._env_spacing])
      
      [x_ref, y_ref] = self._reference_ball_position
      observation.extend([x_ref/self._env_spacing, y_ref/self._env_spacing])
      
      # [theta_x, theta_y, theta_z] = self.get_ballbot_base_orientation_eulerform()
      # observation.extend([np.sin(theta_x), np.sin(theta_y), np.sin(theta_z), np.cos(theta_x), np.cos(theta_y), np.cos(theta_z)])
      # #observation.extend([theta_x/(2*np.pi), theta_y/(2*np.pi), theta_z/(2*np.pi)])
      
      # [LinVelocity, AngVelocity] = self.get_ballbot_base_velocity()
      # [AngVelocity_x, AngVelocity_y, _] = AngVelocity
      # observation.extend([AngVelocity_x/(6*np.pi), AngVelocity_y/(6*np.pi)])
		  
      # [x, y, _] = self.get_ball_position()
      # observation.extend([x/self._env_spacing, y/self._env_spacing])
		  
      # [x_ref, y_ref] = self._reference_ball_position
      # observation.extend([x_ref/self._env_spacing, y_ref/self._env_spacing])
      
      # #[LinVelocity_x, LinVelocity_y, _] = LinVelocity
      # #observation.extend([LinVelocity_x/2, LinVelocity_y/2])
    
    return observation
    
  def GetNoisyObservation(self):
    observation = np.array(self.GetObservation(), dtype=np.float32)
    if self._observation_noise_stdev > 0:
      observation += (np.random.normal(scale=self._observation_noise_stdev, size=observation.shape) * self.GetObservationUpperBound())
      observation = np.clip(observation, self.GetObservationLowerBound(), self.GetObservationUpperBound(), dtype=np.float32)
    return observation
  
  def is_fallen(self):
    """Decide whether the ballbot has fallen.

    If the up directions between the base and the world is larger (the dot
    product is smaller than 0.85) or the base is very low on the ground
    (the height is smaller than 0.13 meter), the ballbot is considered fallen.

    Returns:
      Boolean value that indicates whether the ballbot has fallen.
    """
    orientation = self.get_ballbot_base_orientation()
    rot_mat = self._getMatrixFromQuaternion(orientation)
    local_up = rot_mat[2][:]
    pos = self.get_ballbot_base_position()
    if self._ground_type is None:
        return (np.dot(np.asarray([0, 0, 1]), np.asarray(local_up)) < 0.85 or pos[2] < 0.13)
    else:
        return (np.dot(np.asarray([0, 0, 1]), np.asarray(local_up)) < 0.85)

  def _termination(self):
    position = self.get_ballbot_base_position()
    distance = math.sqrt(position[0]**2 + position[1]**2)
    if self._is_render:
      return self.is_fallen() or distance > self._distance_limit or self._env_closed
    else:
      return self.is_fallen() or distance > self._distance_limit

  def _truncation(self):
    return self._env_step_counter >= self._env_max_episode_length
    
  def _reward(self):
    [ball_x, ball_y, _] = self.get_ball_position()
    ball_position = np.array([ball_x, ball_y])
    
    if self._operation_mode==0:
      # Define weight coefficients
      angular_velocity_weight = 0.5
      tilt_angle_weight = 10
      center_deviation_weight = 0.5
      smoothness_weight = 0.1
        
      [LinVelocity, AngVelocity] = self.get_ballbot_base_velocity()
      velocity_penalty = np.linalg.norm(AngVelocity)
		
      [theta_x, theta_y, theta_z] = self.get_ballbot_base_orientation_eulerform()
      tilt_angle_penalty = ((self._theta_x_desired - theta_x) ** 2 + (self._theta_y_desired - theta_y) ** 2)
		
      [base_x, base_y, _] = self.get_ballbot_base_position()
      base_position = np.array([base_x, base_y])
      center_deviation_penalty = base_position - ball_position
      center_deviation_penalty = np.sum(center_deviation_penalty ** 2)
		
      action_diff = np.diff(self._action_history, axis=0) if len(self._action_history) > 1 else np.zeros_like(self._action_history)
      smoothness_penalty = np.sum(action_diff ** 2)
		
      balancing_penalty = velocity_penalty * angular_velocity_weight + tilt_angle_penalty * tilt_angle_weight + center_deviation_penalty * center_deviation_weight + smoothness_penalty * smoothness_weight
      
      reward = 0
      # Generate new desired angles
      if abs(self._theta_x_desired - theta_x) < 1e-3:
        [self._theta_x_desired, _] = self.generate_random_desired_angles(self._max_angle_desired)
        print("theta_x reached")
        reward += 1
      if abs(self._theta_y_desired - theta_y) < 1e-3:
        [_, self._theta_y_desired] = self.generate_random_desired_angles(self._max_angle_desired)
        print("theta_y reached")
        reward += 1
      
      #transition_timestep = 500
      balance_weight = 1.2 #max(1.0 - self._env_step_counter / transition_timestep, 0)
      #tracking_weight = min(self._env_step_counter / transition_timestep, 1.0)
      reward += 1 - balancing_penalty * balance_weight
    #print("Balancing: ", balancing_penalty)
    
    
    elif(self._operation_mode==1):  # Reference Tracking Training Mode
      #[ballbot_LinVelocity, _] = self.get_ball_velocity()
      #[ballbot_LinVelocity_x, ballbot_LinVelocity_y, _] = ballbot_LinVelocity
      [ref_x,ref_y] = self._reference_ball_position
      #tracking_position_penalty = np.linalg.norm(self._reference_ball_position / self._env_spacing - ball_position / self._env_spacing)
      tracking_position_penalty = np.linalg.norm(self._reference_ball_position - ball_position ,ord=2)
      #tracking_velocity_penalty = (ballbot_LinVelocity_x)**2 + (ballbot_LinVelocity_y)**2
    
      tracking_position_weight = 100 #0.1
      #tracking_velocity_weight = 0.1 #0
      
      tracking_penalty = tracking_position_penalty * tracking_position_weight
      
      #balance_weight = 0
      #tracking_weight = 1
      if tracking_position_penalty < 0.05:
        print("Reference changed!")
        reward = 200
        self.set_ball_reference_position(self.generate_random_reference_position_within_radius(self._radius))
      elif tracking_position_penalty > self._radius:
        reward = -0.1
      else:
        reward = 1 / (tracking_penalty+1e-6) #* tracking_weight
    
    # if not self._operation_mode:
    # #if calculate_balance:
      # #if self._previous_tracking_penalty < tracking_penalty:
      # #  tracking_penalty += 5
      
      # if tracking_position_penalty < 5e-3 and tracking_velocity_penalty < 0.3: 
        # tracking_penalty -= 100
        # #self._stable_time_reward = 1
        # if self._radius < 0.25:
          # self._radius += 0.01
        # self.set_ball_reference_position(self.generate_random_reference_position_within_radius(self._radius))
        # print("Reference Changed!")
    
      # elif tracking_position_penalty < 0.1 and tracking_velocity_penalty < 0.3:
        # tracking_penalty -= -10.42 * tracking_position_penalty + 1.05
        # tracking_penalty += tracking_velocity_penalty * tracking_velocity_weight
            
      # else:
        # #tracking_penalty *= 2
        # tracking_penalty += tracking_velocity_penalty * tracking_velocity_weight
      
      # #self._previous_tracking_penalty = tracking_penalty
      
      # #else:
        # #self._stable_time_reward *= 0.999
      
      # #if tracking_position_penalty < 1e-3 and tracking_velocity_penalty < 0.2: 
      # #  self.reference_change_count += 1
      # #  tracking_penalty -= 100 * self.reference_change_count
      # #  self.set_ball_reference_position(self.generate_random_reference_position_within_radius(self._radius))
      # #  print("Reference Changed..", self.reference_change_count)
    
    elif(self._operation_mode==2):  # Testing Mode
      reward = 1
      
    return reward
                    
  def get_objectives(self):
    return self._objectives

  def _2D_to_3d_RGBA(self, image_2D):
    """
    Convert a 2D array in the shape [h,w*4] to a 3D RGBA in the shape [h,w,4]
    """
    image_RGBA = np.zeros((RENDER_HEIGHT, RENDER_WIDTH, 4), dtype=np.uint8)
    for i in range(image_2D.shape[0]):
        for j in range(image_2D.shape[1]):
            if(j%4==0):
                image_RGBA[i,int(j/4),0]=image_2D[i,j]
                image_RGBA[i,int(j/4),1]=image_2D[i,j+1]
                image_RGBA[i,int(j/4),2]=image_2D[i,j+2]
                image_RGBA[i,int(j/4),3]=image_2D[i,j+3]
    return image_RGBA
  
  def _getMatrixFromQuaternion(self, Q):
    """
    Covert a quaternion into a full three-dimensional rotation matrix.
 
    Input
    :param Q: A 4 element array representing the quaternion (qx,qy,qz,qw) = (x,y,z,w)
              where Q = qxi+qyj+qzk+qw
 
    Output
    :return: A 3x3 element matrix representing the full 3D rotation matrix. 
             This rotation matrix converts a point in the local reference 
             frame to a point in the global reference frame.
    """
    # Extract the values from Q
    qx = Q[0]
    qy = Q[1]
    qz = Q[2]
    qw = Q[3]
     
    # First row of the rotation matrix
    r00 = 1 - 2*qy*qy - 2*qz*qz
    r01 = 2*qx*qy - 2*qz*qw
    r02 = 2*qx*qz + 2*qy*qw
     
    # Second row of the rotation matrix
    r10 = 2*qx*qy + 2*qz*qw	
    r11 = 1 - 2*qx*qx - 2*qz*qz
    r12 = 2*qy*qz - 2*qx*qw
     
    # Third row of the rotation matrix
    r20 = 2*qx*qz - 2*qy*qw
    r21 = 2*qy*qz + 2*qx*qw
    r22 = 1 - 2*qx*qx - 2*qy*qy
     
    # 3x3 rotation matrix
    rot_matrix = np.array([[r00, r01, r02],
                           [r10, r11, r12],
                           [r20, r21, r22]])
                            
    return rot_matrix.tolist()
  
  
  def close(self):
    if not self._env_closed:
      self._env_closed = True
      if self._is_render and self._env_num == 0:
        self._gym_client.destroy_viewer(self.viewer)
      self._gym_client.destroy_sim(self._sim_client)

  if parse_version(gym.__version__) < parse_version('0.9.6'):
    _render = render
    _reset = reset
    _seed = seed
    _step = step



"""This file implements the gym environment of ballbot.

"""

import os, inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(os.path.dirname(currentdir))
os.sys.path.insert(0, parentdir)

from typing import Optional, Dict

import gymnasium as gym
from gymnasium import spaces
from gymnasium import error
import numpy as np

from . import ballbot_gym_env

OBSERVATION_EPS = 0.01

class BallbotGymEnvHER(ballbot_gym_env.BallbotGymEnv):
    """The gym environment for the ballbot.

    It simulates the locomotion of a ballbot. The state space
    include the angles, velocities and torques for all the omniwheels and the action
    space is the desired omniwheel torque for each omniwheel. The reward function is based
    on how far the ballbot walks in 1000 steps and penalizes the energy
    expenditure.

    """
    metadata = {"render_modes": [None, "human", "rgb_array"]}

    def __init__(
      self,
      render=True,
      time_step=1 / 60,      
      numSubSteps=2,
      env_num=0,
      env_spacing=5,
      env_max_episode_length=1000,
      action_bound=1,
      max_torque=10,
      max_speed=1000,
      num_omniwheels=3,
      ballbot_tilt_weight=0.1,
      ball_movement_weight=0.05,
      stable_time_reward=0.1,
      distance_limit=float("inf"),
      ballbot_light=False,
      built_in_ball=True,
      observation_noise_stdev=0.0,
      pid_control_enabled=True,
      torque_control=True,
      physics_engine_PhysX=True):
        """Initialize the ballbot gym environment.

        Args:
          render: Whether to render the simulation.
          time_step: Step time of the simulation.
          numSubSteps: The number of substeps is another parameter. The bigger it gets, the smoother the simulation becomes.
          action_repeat: The number of simulation steps before actions are applied.
          action_bound: The maximum value of the action
          distance_weight: The weight of the distance term in the reward.
          energy_weight: The weight of the energy term in the reward.
          shake_weight: The weight of the vertical shakiness term in the reward.
          drift_weight: The weight of the sideways drift term in the reward.
          distance_limit: The maximum distance to terminate the episode.
          built_in_ball: Use the ball created inside the simulator or load it from URDF file.
          ballbot_light: Use the light ballbot with the ominwheel and its subwheels are treated as one link.
          observation_noise_stdev: The standard deviation of observation noise.
          self_collision_enabled: Whether to enable self collision in the sim.
          pid_control_enabled: Whether to use pid control for the omniwheels (inactive if accurate_motor_model_enabled is enabled).
          hard_reset: Whether to wipe the simulation and load everything when reset
            is called. If set to false, reset just place the ballbot back to start
            position and set its pose to initial configuration.
          env_randomizer: An EnvRandomizer to randomize the physical properties
            during reset().
        """
        super().__init__(render=render,
                         time_step=time_step,      
                         numSubSteps=numSubSteps,
                         env_num=env_num,
                         env_spacing=env_spacing,
                         env_max_episode_length=env_max_episode_length,
                         action_bound=action_bound,
                         max_torque=max_torque,
                         max_speed=max_speed,
                         num_omniwheels=num_omniwheels,
                         ballbot_tilt_weight=ballbot_tilt_weight,
                         ball_movement_weight=ball_movement_weight,
                         stable_time_reward=stable_time_reward,
                         distance_limit=distance_limit,
                         ballbot_light=ballbot_light,
                         built_in_ball=built_in_ball,
                         observation_noise_stdev=observation_noise_stdev,
                         pid_control_enabled=pid_control_enabled,
                         torque_control=torque_control,
                         physics_engine_PhysX=physics_engine_PhysX)
        
        observation_high = (super().GetObservationUpperBound() + OBSERVATION_EPS)
        observation_low = (super().GetObservationLowerBound() - OBSERVATION_EPS)
        
        achieved_goal_high = observation_high
        achieved_goal_low = observation_low
        #achieved_goal_high = super().GetObservationUpperBound()[4] + OBSERVATION_EPS
        #achieved_goal_high = np.array([achieved_goal_high,achieved_goal_high,achieved_goal_high])
        #achieved_goal_low = -achieved_goal_high
        self.observation_space = spaces.Dict({"observation": spaces.Box(np.float32(observation_low), np.float32(observation_high), shape=(super().GetObservationDimension(),), dtype=np.float32),
                                         
                                            "achieved_goal": spaces.Box(np.float32(achieved_goal_low), np.float32(achieved_goal_high), shape=(len(achieved_goal_high),), dtype=np.float32),
                                         
                                            "desired_goal": spaces.Box(np.float32(achieved_goal_low), np.float32(achieved_goal_high), shape=(len(achieved_goal_high),), dtype=np.float32)})
                                         
                                         
        if not isinstance(self.observation_space, gym.spaces.Dict):
            raise error.Error(
                "GoalEnv requires an observation space of type gym.spaces.Dict"
            )
        for key in ["observation", "achieved_goal", "desired_goal"]:
            if key not in self.observation_space.spaces:
                raise error.Error(
                    'GoalEnv requires the "{}" key to be part of the observation dictionary.'.format(
                        key
                    )
                )

    def reset(self,*, seed: Optional[int] = None, options: Optional[Dict] = None):
        [observation, info] = super().reset(seed=seed)
        achieved_goal = observation
        self.desired_goal = np.array([0,0,1,1,0,0], dtype=np.float32)
        #[LinVelocity, AngVelocity] = super().get_ballbot_base_velocity()
        #achieved_goal = np.array(AngVelocity, dtype=np.float32)/(6*np.pi)
        #self.desired_goal = np.array([0,0,0], dtype=np.float32)
        goal_observation = dict(observation=observation, achieved_goal=achieved_goal, desired_goal=self.desired_goal)

        return goal_observation, info
  
    def step(self, action):
        [observation, reward, done, truncated, info] = super().step(action)
        achieved_goal = observation
        #[LinVelocity, AngVelocity] = super().get_ballbot_base_velocity()
        #achieved_goal = np.array(AngVelocity, dtype=np.float32)/(6*np.pi)
        goal_observation = dict(observation=observation, achieved_goal=achieved_goal, desired_goal=self.desired_goal)
        
        reward = self.compute_reward(goal_observation['achieved_goal'], goal_observation['desired_goal'], info)
        done = self.compute_terminated(goal_observation['achieved_goal'], goal_observation['desired_goal'], info)
        truncated = self.compute_truncated(goal_observation['achieved_goal'], goal_observation['desired_goal'], info)
        return goal_observation, reward, done, truncated, info
  
    def compute_reward(self, achieved_goal, desired_goal, info):
        """Compute the step reward. This externalizes the reward function and makes
        it dependent on a desired goal and the one that was achieved. If you wish to include
        additional rewards that are independent of the goal, you can include the necessary values
        to derive it in 'info' and compute it accordingly.

        Args:
            achieved_goal (object): the goal that was achieved during execution
            desired_goal (object): the desired goal that we asked the agent to attempt to achieve
            info (dict): an info dictionary with additional information

        Returns:
            float: The reward that corresponds to the provided achieved goal w.r.t. to the desired
            goal. Note that the following should always hold true:

                ob, reward, terminated, truncated, info = env.step()
                assert reward == env.compute_reward(ob['achieved_goal'], ob['desired_goal'], info)
        """
        if achieved_goal.ndim > 1:
            velocity_penalty = np.linalg.norm(achieved_goal - desired_goal, axis=1)
        else:
            velocity_penalty = np.linalg.norm(achieved_goal - desired_goal)
        
        return self._stable_time_reward - velocity_penalty * self._ballbot_tilt_weight
  
    def compute_terminated(self, achieved_goal, desired_goal, info):
        """Compute the step termination. Allows to customize the termination states depending on the
        desired and the achieved goal. If you wish to determine termination states independent of the goal,
        you can include necessary values to derive it in 'info' and compute it accordingly. The envirtonment reaches
        a termination state when this state leads to an episode ending in an episodic task thus breaking .
        More information can be found in: https://farama.org/New-Step-API#theory

        Termination states are

        Args:
            achieved_goal (object): the goal that was achieved during execution
            desired_goal (object): the desired goal that we asked the agent to attempt to achieve
            info (dict): an info dictionary with additional information

        Returns:
            bool: The termination state that corresponds to the provided achieved goal w.r.t. to the desired
            goal. Note that the following should always hold true:

                ob, reward, terminated, truncated, info = env.step()
                assert terminated == env.compute_terminated(ob['achieved_goal'], ob['desired_goal'], info)
        """
        return super()._termination()
  
    def compute_truncated(self, achieved_goal, desired_goal, info):
        """Compute the step truncation. Allows to customize the truncated states depending on the
        desired and the achieved goal. If you wish to determine truncated states independent of the goal,
        you can include necessary values to derive it in 'info' and compute it accordingly. Truncated states
        are those that are out of the scope of the Markov Decision Process (MDP) such as time constraints in a
        continuing task. More information can be found in: https://farama.org/New-Step-API#theory

        Args:
            achieved_goal (object): the goal that was achieved during execution
            desired_goal (object): the desired goal that we asked the agent to attempt to achieve
            info (dict): an info dictionary with additional information

        Returns:
            bool: The truncated state that corresponds to the provided achieved goal w.r.t. to the desired
            goal. Note that the following should always hold true:

                ob, reward, terminated, truncated, info = env.step()
                assert truncated == env.compute_truncated(ob['achieved_goal'], ob['desired_goal'], info)
        """
        return super()._truncation()
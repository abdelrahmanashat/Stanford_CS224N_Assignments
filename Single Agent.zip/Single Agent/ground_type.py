from enum import Enum


class GroundType(Enum):
    """
    The ground types available in IsaacGym.
    """
    GROUND_RANDOM_UNIFORM = 0
    GROUND_SLOPED = 1
    GROUND_PYRAMID_SLOPED = 2
    GROUND_DISCRETE_OBSTACLES = 3
    GROUND_WAVE = 4
    GROUND_STAIRS = 5
    GROUND_PYRAMID_STAIRS = 6
    GROUND_STEPPING_STONES = 7
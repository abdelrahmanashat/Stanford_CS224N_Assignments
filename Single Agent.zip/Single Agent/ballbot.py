"""This file implements the functionalities of a ballbot using IsaacGym.

"""
import numpy as np
import random
import os
from isaacgym import gymapi
from .ground_type import GroundType

BALLBOT_COLOR = [[0.8039, 0.8509, 1],[0.6274, 0.7215, 1],[0, 0, 0.4]] #[Bot,Omniwheel,Subwheel]
BALLBOT_INIT_POSITION = [0, 0, .2624]
BALLBOT_INIT_ORIENTATION = [0, 0, 0, 1]
BALL_RADIUS = 0.112
BALL_MASS = 1.4373 
BALL_DENSITY = BALL_MASS / ((4/3)*np.pi*BALL_RADIUS**3)
BALL_COLOR = [0.659,0.008,0.357]
BALL_INIT_POSITION = [0, 0, BALL_RADIUS]
BALL_INIT_ORIENTATION = [0, 0, 0, 1]
OBJECT_COLOR = [0.71, 0.686, 0]
OBJECT_MASS = 0.5
OBJECT_WIDTH = 0.06
OBJECT_HEIGHT = 0.112
OBJECT_DEPTH = 0.06
OBJECT_DENSITY = OBJECT_MASS / (np.pi * OBJECT_WIDTH * OBJECT_HEIGHT * OBJECT_DEPTH)
OBJECT_INIT_POSITION = [0, 0, 0.5]
OBJECT_INIT_ORIENTATION = [0, 0, 0, 1]
OMNIWHEEL_RADIUS = 0.05
ALPHA = 45

NUM_SUBWHEELS_PER_OMNIWHEEL = 9
OMNIWHEEL_JOINT_NAMES = ["Joint-Omniwheel-1", "Joint-Omniwheel-2", "Joint-Omniwheel-3"]
OMNIWHEEL_LINK_NAMES = ["Omniwheel-1", "Omniwheel-2", "Omniwheel-3"]
SUBWHEEL_JOINT_NAMES = ["Joint-Subwheel-{}.{}".format(j,i) for j in range (1,3+1) for i in range(1,NUM_SUBWHEELS_PER_OMNIWHEEL+1)]
SUBWHEEL_LINK_NAMES = ["Subwheel-{}.{}".format(j,i) for j in range (1,3+1) for i in range(1,NUM_SUBWHEELS_PER_OMNIWHEEL+1)]

class Ballbot(object):
  """The ballbot class that simulates a ballbot robot.

  """

  def __init__(self,
               sim_client,
               gym_client,
               env,
               collision_group,
               urdf_root=os.path.join(os.path.dirname(__file__), "../Ballbot URDF Packages"),
               built_in_ball=True,
               ballbot_light=False,
               add_object=True,
               ground_type=None,
               torque_control=True,
               max_torque=10,
               max_speed=1000,
               pid_control_enabled=True,
               physics_engine_PhysX=True,
               random_start_position=False,
               num_omniwheels=3):
    """Constructs a ballbot and reset it to the initial states.

    Args:
      sim_client: The instance of sim from IsaacGym.
      gym_client: The instance of gym from IsaacGym.
      env: The instance of the environment in which this instace of ballbot exists. 
      collision_group: An integer that identifies the collision group to which the actor’s bodies will be assigned. 
                       Two bodies will only collide with each other if they belong to the same collision group. 
                       It is common to have one collision group per environment, in which case the group id corresponds to the environment index. 
                       This prevents actors in different environments from interacting with each other physically. 
      urdf_root: The path to the urdf folder.
      built_in_ball: Use the ball created inside the simulator or load it from URDF file.
      ballbot_light: Use the light ballbot with the ominwheel and its subwheels are treated as one link.
      pid_control_enabled: Whether to use pid control for the motors.
    """
    self._num_omniwheels = num_omniwheels
    self._sim_client = sim_client
    self._gym_client = gym_client
    self._env = env
    self._collision_group = collision_group
    self._urdf_root = urdf_root
    self._built_in_ball = built_in_ball
    self._ballbot_light = ballbot_light
    self._add_object = add_object
    self._ground_type = ground_type
    self._torque_control = torque_control
    self._max_torque = max_torque
    self._max_speed = max_speed
    self._pid_control_enabled = pid_control_enabled
    self._physics_engine_PhysX = physics_engine_PhysX
    self._random_start_position = random_start_position
    
    # Adjust position of the ballbot depending on the physics engine for stability
    if not self._physics_engine_PhysX:
        BALLBOT_INIT_POSITION[2] = BALLBOT_INIT_POSITION[2]+0.007
        BALL_INIT_POSITION[2] = BALL_INIT_POSITION[2]+0.004
    
    # Adjust position of the ballbot depending on the ground type as the ground can be far away
    if self._ground_type is not None:
        if self._ground_type == GroundType.GROUND_RANDOM_UNIFORM:
            BALLBOT_INIT_POSITION[2] = BALLBOT_INIT_POSITION[2]+0.1
            BALL_INIT_POSITION[2] = BALL_INIT_POSITION[2]+0.1
        elif self._ground_type == GroundType.GROUND_SLOPED:
            BALLBOT_INIT_POSITION[2] = BALLBOT_INIT_POSITION[2]-0.7
            BALL_INIT_POSITION[2] = BALL_INIT_POSITION[2]-0.7
        elif self._ground_type == GroundType.GROUND_PYRAMID_SLOPED:
            BALLBOT_INIT_POSITION[0] = BALLBOT_INIT_POSITION[0]-4
            BALLBOT_INIT_POSITION[1] = BALLBOT_INIT_POSITION[1]-4
            BALL_INIT_POSITION[0] = BALL_INIT_POSITION[0]-4
            BALL_INIT_POSITION[1] = BALL_INIT_POSITION[1]-4
        elif self._ground_type == GroundType.GROUND_DISCRETE_OBSTACLES:
            BALLBOT_INIT_POSITION[2] = BALLBOT_INIT_POSITION[2]+0.1
            BALL_INIT_POSITION[2] = BALL_INIT_POSITION[2]+0.1
        elif self._ground_type == GroundType.GROUND_WAVE:
            BALLBOT_INIT_POSITION[2] = BALLBOT_INIT_POSITION[2]+0.3
            BALL_INIT_POSITION[2] = BALL_INIT_POSITION[2]+0.3
        elif self._ground_type == GroundType.GROUND_STAIRS:
            BALLBOT_INIT_POSITION[2] = BALLBOT_INIT_POSITION[2]-0.8
            BALL_INIT_POSITION[2] = BALL_INIT_POSITION[2]-0.8
        elif self._ground_type == GroundType.GROUND_PYRAMID_STAIRS:
            BALLBOT_INIT_POSITION[0] = BALLBOT_INIT_POSITION[0]-2.4
            BALLBOT_INIT_POSITION[1] = BALLBOT_INIT_POSITION[1]-1
            BALL_INIT_POSITION[0] = BALL_INIT_POSITION[0]-2.4
            BALL_INIT_POSITION[1] = BALL_INIT_POSITION[1]-1
            BALLBOT_INIT_POSITION[2] = BALLBOT_INIT_POSITION[2]-0.09
            BALL_INIT_POSITION[2] = BALL_INIT_POSITION[2]-0.09
        elif self._ground_type == GroundType.GROUND_STEPPING_STONES:
            pass
    
    
    self.Reset(reload_urdf=True)
    
    if self._pid_control_enabled:
        co = np.cos(ALPHA * np.pi / 180)
        si = np.sin(ALPHA * np.pi / 180)
        
        self.Jac_Inv = np.array([[2/(3*co), 0,                   1/(3*si)],
                                 [-1/(3*co), -1/(np.sqrt(3)*co), 1/(3*si)],
                                 [-1/(3*co), 1/(np.sqrt(3)*co),  1/(3*si)]])
                                 
        #self.Jac_Inv = np.array([[2/(3*co), 0,                   1/3],
        #                         [-1/(3*co), -1/(np.sqrt(3)*co), 1/3],
        #                         [-1/(3*co), 1/(np.sqrt(3)*co),  1/3]])                         
    self._current_omniwheel_actions = np.array([0, 0, 0])

  def Reset(self, reload_urdf=False):
    """Reset the ballbot to its initial states.

    Args:
      reload_urdf: Whether to reload the urdf file. If not, Reset() just place
        the ballbot back to its starting position.
    """
    if reload_urdf:
        pose_ballbot = gymapi.Transform()
        pose_ballbot.p = gymapi.Vec3(*BALLBOT_INIT_POSITION) 
        pose_ballbot.r = gymapi.Quat(*BALLBOT_INIT_ORIENTATION)
        collision_filter_ballbot = 1
        if self._ballbot_light:
            asset_options = gymapi.AssetOptions()
            asset_options.max_angular_velocity = 6 * np.pi
            self.ballbotAsset = self._gym_client.load_asset(self._sim_client, self._urdf_root, "Ballbot_Light/urdf/Ballbot_Light.urdf", asset_options)
            self.ballbotID = self._gym_client.create_actor(self._env, self.ballbotAsset, pose_ballbot, "Ballbot", self._collision_group, collision_filter_ballbot)
        else:
            asset_options = gymapi.AssetOptions()
            asset_options.max_angular_velocity = 6 * np.pi
            self.ballbotAsset = self._gym_client.load_asset(self._sim_client, self._urdf_root, "Ballbot/urdf/Ballbot.urdf", asset_options)
            self.ballbotID = self._gym_client.create_actor(self._env, self.ballbotAsset, pose_ballbot, "Ballbot", self._collision_group, collision_filter_ballbot)
        
        pose_ball = gymapi.Transform()
        pose_ball.p = gymapi.Vec3(*BALL_INIT_POSITION) 
        pose_ball.r = gymapi.Quat(*BALL_INIT_ORIENTATION)
        collision_filter_ball = 2
        if self._built_in_ball:
            asset_options = gymapi.AssetOptions()
            asset_options.density = BALL_DENSITY
            asset_options.max_angular_velocity = np.pi / 2
            self.ballAsset = self._gym_client.create_sphere(self._sim_client,BALL_RADIUS,asset_options)
            self.ballID = self._gym_client.create_actor(self._env, self.ballAsset, pose_ball, "Ball", self._collision_group, collision_filter_ball)
        else:
            asset_options = gymapi.AssetOptions()
            asset_options.max_angular_velocity = np.pi / 2
            self.ballAsset = self._gym_client.load_asset(self._sim_client, self._urdf_root, "Ball/urdf/Ball.urdf", asset_options)
            self.ballID = self._gym_client.create_actor(self._env, self.ballAsset, pose_ball, "Ball", self._collision_group, collision_filter_ball)
        
        pose_object = gymapi.Transform()
        pose_object.p = gymapi.Vec3(*OBJECT_INIT_POSITION) 
        pose_object.r = gymapi.Quat(*OBJECT_INIT_ORIENTATION)
        collision_filter_object = 4
        if self._add_object:
            asset_options = gymapi.AssetOptions()
            asset_options.density = OBJECT_DENSITY
            self.objectAsset = self._gym_client.create_box(self._sim_client,OBJECT_WIDTH,OBJECT_HEIGHT,OBJECT_DEPTH,asset_options)
            self.objectID = self._gym_client.create_actor(self._env, self.objectAsset, pose_object, "Object", self._collision_group, collision_filter_object)

        self._gym_client.enable_actor_dof_force_sensors(self._env, self.ballbotID)
        
        # Get Ballbot and Ball Initial States for Reset Function
        #self._ballbot_init_state = (self._gym_client.get_actor_rigid_body_states(self._env, self.ballbotID, gymapi.STATE_ALL)).copy()
        self._ballbot_init_linear_velocity = self._gym_client.get_rigid_linear_velocity(self._env, self.ballbotID)
        self._ballbot_init_angular_velocity = self._gym_client.get_rigid_angular_velocity(self._env, self.ballbotID)
        self._ballbot_init_transform = self._gym_client.get_rigid_transform(self._env, self.ballbotID)
        self._ball_init_state = (self._gym_client.get_actor_rigid_body_states(self._env, self.ballID, gymapi.STATE_ALL)).copy()
        if self._add_object:   
           self._object_init_state = (self._gym_client.get_actor_rigid_body_states(self._env, self.objectID, gymapi.STATE_ALL)).copy()
        
        # Joint Dictionary
        self._BuildJointNameToIdDict()
        self._BuildOmniwheelJointIdList()
        if not self._ballbot_light:
            self._BuildSubwheelJointIdList()
        
        # Link Dictionary
        self._BuildLinkNameToIdDict()
        self._BuildOmniwheelLinkIdList()
        if not self._ballbot_light:
            self._BuildSubwheelLinkIdList()            
        
        # Link properties
        self._PrepareLinkProperties()
        
        # Joint States and Properties
        self._PrepareJointProperties()
        self._ResetAllWheelsState()
        
        # Set Body Colors
        self._SetSimulationColors()
        
        #a = self._gym_client.get_actor_rigid_shape_properties(self._env,self.ballID)
        #print(a[0].compliance)
        #print(a[0].contact_offset)
        #print(a[0].filter)
        #print(a[0].friction)
        #print(a[0].rest_offset)
        #print(a[0].restitution)
        #print(a[0].rolling_friction)
        #print(a[0].torsion_friction)
        #print("\n")
        
        #a = self._gym_client.get_actor_rigid_shape_properties(self._env,self.ballbotID)
        #for i in a:
        #    print(i.compliance)
        #    print(i.contact_offset)
        #    print(i.filter)
        #    print(i.friction)
        #    print(i.rest_offset)
        #    print(i.restitution)
        #    print(i.rolling_friction)
        #    print(i.torsion_friction)
        #    print("\n")
        
    else:
        #Randomizing starting points
        if self._ground_type is None and self._random_start_position:
            RADIUS = 2.5
            r = RADIUS * np.sqrt(random.random())
            theta = random.random() * 2 * np.pi
            distance_x = r * np.cos(theta)
            distance_y = r * np.sin(theta)
            self._ballbot_init_transform.p.x = distance_x
            self._ballbot_init_transform.p.y = distance_y
            self._ball_init_state["pose"]["p"][0] = (distance_x, distance_y, BALL_INIT_POSITION[2])
        self._ResetBallbotPositionAndOrientation()
        self._ResetBallPositionAndOrientation()
        if self._add_object:
            self._ResetObjectPositionAndOrientation()
        self._ResetAllWheelsState()
        

  def _BuildJointNameToIdDict(self):
    self._joint_name_to_id = self._gym_client.get_actor_dof_dict(self._env,self.ballbotID)

  def _BuildOmniwheelJointIdList(self):
    self._omniwheel_joint_id_list = [self._joint_name_to_id[omniwheel_name] for omniwheel_name in OMNIWHEEL_JOINT_NAMES]
    
  def _BuildSubwheelJointIdList(self):
    self._subwheel_joint_id_list = [self._joint_name_to_id[subwheel_name] for subwheel_name in SUBWHEEL_JOINT_NAMES]
    
  def _BuildLinkNameToIdDict(self):
    self._link_name_to_id = self._gym_client.get_actor_rigid_body_dict(self._env,self.ballbotID)

  def _BuildOmniwheelLinkIdList(self):
    self._omniwheel_link_id_list = [self._link_name_to_id[omniwheel_name] for omniwheel_name in OMNIWHEEL_LINK_NAMES]
  
  def _BuildSubwheelLinkIdList(self):
    self._subwheel_link_id_list = [self._link_name_to_id[subwheel_name] for subwheel_name in SUBWHEEL_LINK_NAMES]

  def _PrepareLinkProperties(self):
    """Prepares the omniwheel links to have exact values of friction
    """
    # Prepare ballbot properties
    ballbot_friction = 1.5
    ballbot_properties = self._gym_client.get_actor_rigid_shape_properties(self._env,self.ballbotID)
    for i in self._omniwheel_link_id_list:
        ballbot_properties[i].friction = ballbot_friction
    if not self._ballbot_light:
        for i in self._subwheel_link_id_list:
            ballbot_properties[i].friction = ballbot_friction
    self._gym_client.set_actor_rigid_shape_properties(self._env,self.ballbotID, ballbot_properties)
    
    # Prepare ball properties
    ball_friction = 1.9
    ball_properties = self._gym_client.get_actor_rigid_shape_properties(self._env,self.ballID)
    ball_properties[0].friction = ball_friction
    self._gym_client.set_actor_rigid_shape_properties(self._env,self.ballID, ball_properties)
      
  def _PrepareJointProperties(self):
    """Prepares the omniwheel joints to be driven by torque
       and sets other joint properties
    """
    dof_properties = self._gym_client.get_actor_dof_properties(self._env, self.ballbotID)
    
    if self._torque_control:
        # Change drive mode to torque mode for omniwheel joints
        for omniwheel_id in self._omniwheel_joint_id_list:
            dof_properties["driveMode"][omniwheel_id] = gymapi.DOF_MODE_EFFORT
            dof_properties["effort"][omniwheel_id] = self._max_torque
            dof_properties["velocity"][omniwheel_id] = self._max_speed
            
        # Change stiffness of all joints (including subwheels) to zero for easy movement
        for i in range(len(self._joint_name_to_id)):
            dof_properties["stiffness"][i] = 0.0
            dof_properties["damping"][i] = 0.0
    else:
        # Change drive mode to position mode for omniwheel joints
        for omniwheel_id in self._omniwheel_joint_id_list:
            dof_properties["driveMode"][omniwheel_id] = gymapi.DOF_MODE_POS
            dof_properties["effort"][omniwheel_id] = self._max_torque
            dof_properties["velocity"][omniwheel_id] = self._max_speed
            dof_properties["stiffness"][omniwheel_id] = 1000.0
            dof_properties["damping"][omniwheel_id] = 200.0
        
        # Change stiffness of subwheels to zero for easy movement
        if not self._ballbot_light:
            for subwheel_id in self._subwheel_joint_id_list:
                dof_properties["stiffness"][subwheel_id] = 0.0
                dof_properties["damping"][subwheel_id] = 0.0

    self._gym_client.set_actor_dof_properties(self._env, self.ballbotID, dof_properties)

  
  def _ResetAllWheelsState(self):
    """Reset the position, velocity, and torque of omniwheels (and subwheels if there are any).
    """
    states = np.empty((len(self._joint_name_to_id)), dtype=gymapi.DofState)
    for state in states:
        state['pos'] = 0
        state['vel'] = 0
    self._gym_client.set_actor_dof_states(self._env, self.ballbotID, states, gymapi.STATE_ALL) 
    torques = self._gym_client.get_actor_dof_forces(self._env, self.ballbotID)
    for omniwheel_id in self._omniwheel_joint_id_list:
        torques[omniwheel_id] = 0
    self._gym_client.apply_actor_dof_efforts(self._env, self.ballbotID, torques)
    
  def _ResetBallbotPositionAndOrientation(self):
    """Reset the position and orientation of ballbot.
    """
    #self._gym_client.set_actor_rigid_body_states(self._env, self.ballbotID, self._ballbot_init_state, gymapi.STATE_ALL)  
    self._gym_client.set_rigid_linear_velocity(self._env, self.ballbotID, self._ballbot_init_linear_velocity)
    self._gym_client.set_rigid_angular_velocity(self._env, self.ballbotID, self._ballbot_init_angular_velocity)
    self._gym_client.set_rigid_transform(self._env, self.ballbotID, self._ballbot_init_transform)
    
  def _ResetBallPositionAndOrientation(self):
    """Reset the position and orientation of ball.
    """
    self._gym_client.set_actor_rigid_body_states(self._env, self.ballID, self._ball_init_state, gymapi.STATE_ALL) 

  def _ResetObjectPositionAndOrientation(self):
    """Reset the position and orientation of ball.
    """
    self._gym_client.set_actor_rigid_body_states(self._env, self.objectID, self._object_init_state, gymapi.STATE_ALL) 
    
  def _SetSimulationColors(self):
    """Set the color of ballbot and ball.
    """
    # set ball color
    ball_color = gymapi.Vec3(*BALL_COLOR) 
    self._gym_client.set_rigid_body_color(self._env,self.ballID,0,gymapi.MESH_VISUAL,ball_color)
    
    # set object color
    if self._add_object: 
        object_color = gymapi.Vec3(*OBJECT_COLOR) 
        self._gym_client.set_rigid_body_color(self._env,self.objectID,0,gymapi.MESH_VISUAL,object_color)
    
    # set ballbot color
    bot_color = gymapi.Vec3(*BALLBOT_COLOR[0])
    self._gym_client.set_rigid_body_color(self._env,self.ballbotID,0,gymapi.MESH_VISUAL,bot_color)
    omniwheel_color = gymapi.Vec3(*BALLBOT_COLOR[1])
    for i in self._omniwheel_link_id_list:
        self._gym_client.set_rigid_body_color(self._env,self.ballbotID,i,gymapi.MESH_VISUAL,omniwheel_color)
    if not self._ballbot_light:
        subwheel_color = gymapi.Vec3(*BALLBOT_COLOR[2])
        for i in self._subwheel_link_id_list:
            self._gym_client.set_rigid_body_color(self._env,self.ballbotID,i,gymapi.MESH_VISUAL,subwheel_color)  
                    
  def GetBasePosition(self):
    """Get the position of ballbot's base.

    Returns:
      The position of ballbot's base in the following order: [x,y,z].
    """
    ballbot_state = self._gym_client.get_rigid_transform(self._env, self.ballbotID)
    position = ballbot_state.p
    return [position.x, position.y, position.z]
    
  def GetBaseOrientation(self):
    """Get the orientation of ballbot's base, represented as quaternion.

    Returns:
      The orientation of ballbot's base in quaternion form in the following order: [x,y,z,w].
    """
    ballbot_state = self._gym_client.get_rigid_transform(self._env, self.ballbotID)
    orientation = ballbot_state.r
    return [orientation.x, orientation.y, orientation.z, orientation.w]
    
  def GetBaseOrientationEulerForm(self):
    """Get the orientation of ballbot's base, represented as Euler.

    Returns:
      The orientation of ballbot's base in Euler form: theta_x, theta_y, theta_z in rad
      where theta_x is the orientation around x-axis
           ,theta_y is the orientation around y-axis
           ,theta_z is the orientation around z-axis
    """
    ori = gymapi.Quat(*self.GetBaseOrientation())
    ori_euler = list(ori.to_euler_zyx())      #The order is [theta_x, theta_y, theta_z]
    return ori_euler
  
  def GetBaseVelocity(self):
    """Get the velocity of ballbot's base.

    Returns:
      The velocity of ballbot's base in the following order: [Linear Velocity, Angular Velocity].
    """
    LinVelocity = self._gym_client.get_rigid_linear_velocity(self._env, self.ballbotID)
    LinVelocity = [LinVelocity.x, LinVelocity.y, LinVelocity.z]
    AngVelocity = self._gym_client.get_rigid_angular_velocity(self._env, self.ballbotID)
    AngVelocity = [AngVelocity.x, AngVelocity.y, AngVelocity.z]
    return [LinVelocity, AngVelocity]
  
  def GetBallPosition(self):
    """Get the position of ball.

    Returns:
      The position of ball.
    """
    ball_state = self._gym_client.get_actor_rigid_body_states(self._env, self.ballID, gymapi.STATE_POS)
    (position, _) = ball_state["pose"][0]
    return list(position)

  def GetBallOrientation(self):
    """Get the orientation of ball's base, represented as quaternion.

    Returns:
      The orientation of ball's base.
    """
    ball_state = self._gym_client.get_actor_rigid_body_states(self._env, self.ballID, gymapi.STATE_POS)
    (_, orientation) = ball_state["pose"][0]
    return list(orientation)
  
  def GetBallOrientationEulerForm(self):
    """Get the orientation of ball's base, represented as Euler.

    Returns:
      The orientation of ball's base in Euler form.
    """
    ori = gymapi.Quat(*self.GetBallOrientation())
    ori_euler = list(ori.to_euler_zyx())
    #ori_euler.reverse()
    return ori_euler  
  
  def GetBallVelocity(self):
    """Get the velocity of ball.

    Returns:
      The velocity of ball in the following order: [Linear Velocity, Angular Velocity].
    """
    LinVelocity = self._gym_client.get_rigid_linear_velocity(self._env, self.ballID)
    LinVelocity = [LinVelocity.x, LinVelocity.y, LinVelocity.z]
    AngVelocity = self._gym_client.get_rigid_angular_velocity(self._env, self.ballID)
    AngVelocity = [AngVelocity.x, AngVelocity.y, AngVelocity.z]
    return [LinVelocity, AngVelocity]
    
  def GetObjectPosition(self):
    """Get the position of ball.

    Returns:
      The position of ball.
    """
    if self._add_object: 
      object_state = self._gym_client.get_actor_rigid_body_states(self._env, self.objectID, gymapi.STATE_POS)
      (position, _) = object_state["pose"][0]
      return list(position)
    else:
      return list()
  
  def ApplyAction(self, omniwheel_commands):
    """Set the desired omniwheel angles to the motors of the ballbot.

    The desired omniwheel angles are clipped based on the maximum allowed velocity.
    If the pid_control_enabled is True, a torque is calculated according to
    the difference between current and desired joint angle, as well as the joint
    velocity. This torque is exerted to the omniwheel. For more information about
    pid control, please refer to: https://en.wikipedia.org/wiki/PID_controller.

    Args:
      omniwheel_commands: The three desired omniwheel angles.
    """
    actions = np.array(omniwheel_commands)
    if self._pid_control_enabled:
        actions = np.dot(self.Jac_Inv, actions)
    self._current_omniwheel_actions = actions
    
    if self._torque_control:
        torques = self._gym_client.get_actor_dof_forces(self._env, self.ballbotID)
        for omniwheel_id, action in zip(self._omniwheel_joint_id_list, actions):
            torques[omniwheel_id] = action
        self._gym_client.apply_actor_dof_efforts(self._env, self.ballbotID, torques)
    else:
        positions = self._gym_client.get_actor_dof_position_targets(self._env, self.ballbotID)
        for omniwheel_id, action in zip(self._omniwheel_joint_id_list, actions):
            positions[omniwheel_id] = action
        self._gym_client.set_actor_dof_position_targets(self._env, self.ballbotID, positions)
  
  def ApplyForceAtBallbot(self, force):
    self._gym_client.apply_body_forces(env=self._env, rigidHandle=self.ballbotID, force=force, torque=None, space=gymapi.ENV_SPACE)
  
  def GetOmniwheelAngles(self):
    """Get the three omniwheel angles in radians at the current moment.

    Returns:
      A list of omniwheel angles.
    """
    dof_states = self._gym_client.get_actor_dof_states(self._env, self.ballbotID, gymapi.STATE_POS)
    omniwheel_angles = [dof_states["pos"][omniwheel_id].item() for omniwheel_id in self._omniwheel_joint_id_list]
    omniwheel_angles = (np.array(omniwheel_angles) + np.pi) % (2 * np.pi) - np.pi   # To limit the angles to [-2*pi, 2*pi]
    return omniwheel_angles.tolist()

  def GetOmniwheelVelocities(self):
    """Get the velocity of all three omniwheels in rad/s.

    Returns:
      A list of angular velocities of all three omniwheels.
    """
    dof_states = self._gym_client.get_actor_dof_states(self._env, self.ballbotID, gymapi.STATE_VEL)
    omniwheel_velocities = [dof_states["vel"][omniwheel_id].item() for omniwheel_id in self._omniwheel_joint_id_list]
    return omniwheel_velocities

  def GetOmniwheelTorques(self):
    """Get the amount of torques the omniwheels are exerting in N.m.

    Returns:
      A list of omniwheel torques of all three motors.
    """
    torques = self._gym_client.get_actor_dof_forces(self._env, self.ballbotID)
    omniwheel_torques = [torques[omniwheel_id].item() for omniwheel_id in self._omniwheel_joint_id_list]
    return omniwheel_torques

  def GetBaseMassFromURDF(self):
    """Get the mass of the base from the URDF file."""
    ballbot_properties = self._gym_client.get_actor_rigid_body_properties(self._env, self.ballbotID)
    return ballbot_properties[0].mass

  def GetOmniwheelMassFromURDF(self):
    """Get the mass of the omniwheels from the URDF file."""
    ballbot_properties = self._gym_client.get_actor_rigid_body_properties(self._env, self.ballbotID)
    if self._ballbot_light:
        return ballbot_properties[1].mass
    else:
        return ballbot_properties[1].mass + ballbot_properties[2].mass * NUM_SUBWHEELS_PER_OMNIWHEEL

  def SetBaseMass(self, base_mass):
    """Set the mass of the base of the ballbot."""
    ballbot_properties = self._gym_client.get_actor_rigid_body_properties(self._env, self.ballbotID)
    ballbot_properties[0].mass = base_mass
    self._gym_client.set_actor_rigid_body_properties(self._env, self.ballbotID, ballbot_properties, recomputeInertia=False)

  def SetOmniwheelMasses(self, omniwheel_masses):
    """Set the mass of the omniwheels.

    An omniwheel includes omniwheel link and subwheel link. All three omniwheel links have the same mass,
    which is omniwheel_masses[0]. All nine subwheels have the same mass, which is omniwheel_masses[1].

    Args:
      omniwheel_masses: The omniwheel masses. omniwheel_masses[0] is the mass of the omniwheel.
        omniwheel_masses[1] is the mass of the subwheel.
    """
    ballbot_properties = self._gym_client.get_actor_rigid_body_properties(self._env, self.ballbotID)
    for omniwheel_id in self._omniwheel_link_id_list:
      ballbot_properties[omniwheel_id].mass = omniwheel_masses[0]
    for subwheel_id in self._subwheel_link_id_list:
      ballbot_properties[subwheel_id].mass = omniwheel_masses[1]
    self._gym_client.set_actor_rigid_body_properties(self._env, self.ballbotID, ballbot_properties, recomputeInertia=False)

  

